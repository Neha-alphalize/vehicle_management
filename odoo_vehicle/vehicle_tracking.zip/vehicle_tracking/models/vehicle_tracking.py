# -*- coding: utf-8 -*-
from odoo import api, fields, models
from datetime import datetime

class VehicleTracking(models.Model):
    _name = 'vehicle.tracking'
    _description = 'Vehicle Tracking'
    _rec_name = 'vehicle_id'

    # Header info
    date = fields.Date(string='Date', default=fields.Date.context_today)
    vehicle_id = fields.Many2one('fleet.vehicle', string='Vehicle')
    driver_id = fields.Many2one('res.partner', string='Driver',
                                domain="[('is_company','=',False)]")
    number_plate = fields.Char(string='Number Plate')
    company_id = fields.Many2one('res.company', string='Company',
                                 default=lambda self: self.env.company,
                                 readonly=True)

    # Tracking Details
    source = fields.Selection([
        ('head_office', 'Head Office'),
        ('branch', 'Branch'),
        ('warehouse', 'Warehouse'),
        ('customer_site', 'Customer Site'),
        ('others', 'Others'),
    ], string='Source')

    destination = fields.Selection([
        ('head_office', 'Head Office'),
        ('branch', 'Branch'),
        ('warehouse', 'Warehouse'),
        ('customer_site', 'Customer Site'),
        ('others', 'Others'),
    ], string='Destination')

    start_km = fields.Integer(string='Start Km', default=0)
    end_km = fields.Integer(string='End Km', default=0)
    km_travelled = fields.Integer(string='KM Travelled', compute='_compute_km_travelled', store=True)
    purpose_of_visit = fields.Selection([
        ('delivery', 'Delivery'),
        ('collection', 'Collection'),
        ('inspection', 'Inspection'),
        ('official', 'Official'),
        ('personal', 'Personal'),
    ], string='Purpose of Visit')

    start_time = fields.Datetime(string='Start Time', default=fields.Datetime.now)
    end_time = fields.Datetime(string='End Time')
    duration = fields.Float(string='Duration (Hrs)', compute='_compute_duration', store=True)
    invoice_number = fields.Char(string='Invoice Number')
    amount = fields.Float(string='Amount', compute='_compute_amount', store=True)
    estimated_time = fields.Float(string='Estimated Time (Hrs)', default=00.00)

    coolant_water = fields.Boolean(string='Coolant Water')
    oil_checking = fields.Boolean(string='Oil Checking')
    tyre_checking = fields.Boolean(string='Tyre Checking')
    battery_checking = fields.Boolean(string='Battery Checking')
    daily_checks = fields.Boolean(string='Daily Checks')

    invoice_line_ids = fields.One2many(
        'vehicle.tracking.invoice',   # child model name
        'tracking_id',     
        string='Invoice Details'
    )

    #info section
    start_trip = fields.Boolean(string='Start Trip')
    end_trip = fields.Boolean(string='End Trip')
    trip_cancel = fields.Boolean(string='Trip Cancel')


    start_latitude = fields.Char(string='Start Latitude')
    start_longitude = fields.Char(string='Start Longitude')
    end_latitude = fields.Char(string='End Latitude')
    end_longitude = fields.Char(string='End Longitude')

    image_url = fields.Char(string='Image URL')
    remarks = fields.Text(string='Remarks')


    state = fields.Selection([
        ('draft', 'Draft'),
        ('validated', 'Validated'),
    ], default='draft', string='Status', readonly=True)

    # Compute fields
    @api.depends('start_km', 'end_km')
    def _compute_km_travelled(self):
        for rec in self:
            rec.km_travelled = max(rec.end_km - rec.start_km, 0)

    @api.depends('start_time', 'end_time')
    def _compute_duration(self):
        for rec in self:
            if rec.start_time and rec.end_time:
                delta = rec.end_time - rec.start_time
                rec.duration = round(delta.total_seconds() / 3600, 2)
            else:
                rec.duration = 0.0

    @api.depends('km_travelled', 'duration')
    def _compute_amount(self):
        # You can use any logic to calculate the amount, here we assume a rate per km
        rate_per_km = 10  # Example: 10 units per kilometer
        rate_per_hour = 5  # Example: 5 units per hour of duration

        for rec in self:
            # Calculate the amount based on the distance traveled and duration
            rec.amount = (rec.km_travelled * rate_per_km) + (rec.duration * rate_per_hour)

    @api.onchange('vehicle_id')
    def _onchange_vehicle_id(self):
        if self.vehicle_id:
            self.number_plate = self.vehicle_id.license_plate

    # Buttons
    def action_validate(self):
        for rec in self:
            rec.state = 'validated'
        return {
            'type': 'ir.actions.act_window',
            'name': 'Vehicle Tracking',
            'res_model': 'vehicle.tracking',
            'view_mode': 'list',  # Open the list view
            'view_id': False,  # Default list view
            'target': 'current',  # Stay in the current window
            'context': self.env.context,  # Maintain the context
        }
    

    def action_discard_custom(self):
        """Custom discard button — discard changes and return to the list view."""

        # Reset any changes made to the record (if you have any model-specific reset logic, add it here)
        self.ensure_one()  # Ensure that we are working on one record only
    
        
        self.unlink()
        # Return to the list view without saving
        return {
            'type': 'ir.actions.act_window',
            'name': 'Vehicle Tracking',
            'res_model': 'vehicle.tracking',
            'view_mode': 'list',
            'view_id': False,  # Default list view
            'target': 'current',  # Stay in the current window
            'context': self.env.context,
        }


    # def action_discard_custom(self):
    #     """Custom discard button — shows confirmation and redirects to list view."""
    #     return {
    #         'type': 'ir.actions.act_window',
    #         'name': 'Vehicle Tracking',
    #         'res_model': 'vehicle.tracking',
    #         'view_mode': 'list,form',
    #         'target': 'current',
    #         'views': [(False, 'list'), (False, 'form')],
    #     }
    
    def action_custom_save(self):
        # Save the record (Odoo does this automatically when you save a form)
        self.ensure_one()  # Ensure only one record is processed at a time

        # Return to the list view after saving
        return {
            'type': 'ir.actions.act_window',
            'name': 'Vehicle Tracking',
            'res_model': 'vehicle.tracking',
            'view_mode': 'list',
            'view_id': False,  # Use the default list view
            'target': 'current',
            'context': self.env.context,
        }


    # def action_custom_save(self):
    #     return True
